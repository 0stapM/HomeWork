import java.util.ArrayList;
import java.util.List;

public class GeometryTestMain {
    public static void main(String[] args) {

        Figura[] tablicaFigur = new Figura[4];
        tablicaFigur[0] = new Kwadrat(5);
        tablicaFigur[1] = new Prostokat(4, 6, new Punkt(0, 0));
        tablicaFigur[2] = new Trojkat(3, 4);
        tablicaFigur[3] = new Okrag(new Punkt(1, 1), 3);

        for (Figura f : tablicaFigur) {
            System.out.println(f.opis());
        }


        List<IFigury> listaFigur = new ArrayList<>();
        listaFigur.add((IFigury) tablicaFigur[0]);
        listaFigur.add((IFigury) tablicaFigur[1]);
        listaFigur.add((IFigury) tablicaFigur[2]);
        listaFigur.add((IFigury) tablicaFigur[3]);

        Punkt testPoint = new Punkt(2, 2);
        for (IFigury fig : listaFigur) {
            System.out.println("Area: " + fig.getPowierzchnia());
            System.out.println("Is point (2,2) inside? " + fig.wPolu(testPoint));
        }


        if (tablicaFigur[3] instanceof RuchFigury okrag) {
            okrag.przesun(2, 2);
            System.out.println("Moved circle center to (3,3)");
        }
    }
}