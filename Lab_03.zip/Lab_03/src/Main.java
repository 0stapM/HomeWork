
public static void main(String[] args) {
    System.out.println("Task 1:");
    Lab03Tasks.task1();
    System.out.println("\nTask 2:");
    Lab03Tasks.task2();
    System.out.println("\nTask 3:");
    Lab03Tasks.task3();
    System.out.println("\nTask 4:");
    Lab03Tasks.task4();
    System.out.println("\nTask 5:");
    Lab03Tasks.task5();
}

