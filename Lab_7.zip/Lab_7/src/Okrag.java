public class Okrag extends Figura implements IFigury, RuchFigury {
    private Punkt center;
    private double radius;

    public Okrag(Punkt center, double radius) {
        this.center = center;
        this.radius = radius;
    }

    @Override
    public String opis() {
        return "Object of class Okrag";
    }

    @Override
    public void skaluj(float skala) {
        radius *= skala;
    }

    @Override
    public float getPowierzchnia() {
        return (float) (Math.PI * radius * radius);
    }

    @Override
    public boolean wPolu(Punkt p) {
        double dx = p.x - center.x;
        double dy = p.y - center.y;
        return dx * dx + dy * dy <= radius * radius;
    }

    @Override
    public void przesun(int x, int y) {
        center.x += x;
        center.y += y;
    }
}