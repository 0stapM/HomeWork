import java.util.*;

class Participant {
    int id;
    String name;
    int age;

    public Participant(int id, String name, int age) {
        this.id = id;
        this.name = name;
        this.age = age;
    }

    public boolean isMinor() {
        return age < 18;
    }

    @Override
    public String toString() {
        return id + ": " + name + ", " + age + " yrs";
    }

    @Override
    public boolean equals(Object obj) {
        if (!(obj instanceof Participant)) return false;
        Participant p = (Participant) obj;
        return id == p.id;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}

public class ParticipantsTest {
    public static void main(String[] args) {
        List<Participant> list = new LinkedList<>();
        list.add(new Participant(1, "Anna", 20));
        list.add(new Participant(2, "Tom", 17));

        list.stream().filter(p -> !p.isMinor()).forEach(System.out::println);
    }
}