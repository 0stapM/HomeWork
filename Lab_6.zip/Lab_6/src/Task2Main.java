public class Task2Main {
    public static void main(String[] args) {
        Punkt p1 = new Punkt(2, 3);
        Punkt p2 = new Punkt();
        Punkt p3 = new Punkt(10, 20);

        p1.describe();
        p2.move(5, 5);
        p2.describe();
        p3.reset();
        p3.describe();

        Prostokat rect = new Prostokat(4, 5, "blue");
        rect.describe();
        rect.move(3, 5);

        Trojkat tri = new Trojkat(3, 6, "green");
        tri.describe();

        Okrag circle = new Okrag(new Punkt(0, 0), 5);
        circle.describe();
        System.out.println("Area: " + circle.getArea());
        System.out.println("Contains (3,4)? " + circle.contains(new Punkt(3, 4)));

        Kwadrat square = new Kwadrat(4, "red");
        square.describe();
    }
}