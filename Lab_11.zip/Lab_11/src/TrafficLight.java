public enum TrafficLight {
    RED("Stop!"),
    YELLOW("Caution!"),
    GREEN("Go!");

    private final String message;

    TrafficLight(String message) {
        this.message = message;
    }

    public String getMessage() {
        return message;
    }
}