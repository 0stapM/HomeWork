public interface IFigury {
    float getPowierzchnia();
    boolean wPolu(Punkt p);
}