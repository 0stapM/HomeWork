public class PizzaSizeTest {
    public static void main(String[] args) {
        PizzaSize size = PizzaSize.LARGE;

        System.out.println("Selected size: " + size);
        System.out.println("Diameter: " + size.getDiameter() + " cm");
        System.out.println("Price: $" + size.getPrice());


        for (PizzaSize s : PizzaSize.values()) {
            System.out.printf("%s: %d cm, $%.2f%n", s, s.getDiameter(), s.getPrice());
        }
    }
}