import java.util.*;

public class NamePairs {
    public static void main(String[] args) {
        Map<String, String> pairs = new HashMap<>();
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.print("Enter name 1 ('-' to stop): ");
            String n1 = scanner.nextLine();
            if (n1.equals("-")) break;
            System.out.print("Enter partner: ");
            String n2 = scanner.nextLine();
            pairs.put(n1, n2);
        }

        System.out.print("Lookup name: ");
        String key = scanner.nextLine();
        System.out.println("Partner: " + pairs.getOrDefault(key, "Not found"));
    }
}