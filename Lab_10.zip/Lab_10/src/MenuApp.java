import java.util.*;

public class MenuApp {
    public static void main(String[] args) {
        Map<String, Double> menu = new LinkedHashMap<>();
        menu.put("Pizza", 25.0);
        menu.put("Soup", 12.0);

        Scanner scanner = new Scanner(System.in);
        System.out.println("Menu:");
        menu.forEach((k, v) -> System.out.println(k + " - " + v + " zł"));

        List<String> order = new ArrayList<>();
        System.out.println("Type dish name to order, or '-' to finish:");
        while (true) {
            String dish = scanner.nextLine();
            if (dish.equals("-")) break;
            if (menu.containsKey(dish)) order.add(dish);
        }

        double total = 0;
        for (String dish : order) {
            total += menu.get(dish);
        }

        System.out.println("Bill for " + order + ": " + total + " zł");
    }
}