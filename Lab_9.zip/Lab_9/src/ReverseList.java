import java.util.*;

public class ReverseList {
    public static void main(String[] args) {
        List<Integer> list1 = new ArrayList<>(List.of(1, 2, 3, 4));
        List<Integer> list2 = new ArrayList<>();

        ListIterator<Integer> iter = list1.listIterator(list1.size());
        while (iter.hasPrevious()) {
            list2.add(iter.previous());
        }

        System.out.println("Original: " + list1);
        System.out.println("Reversed: " + list2);
    }
}