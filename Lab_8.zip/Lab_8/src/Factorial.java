class InvalidFactorialValueException extends Exception {
    public InvalidFactorialValueException(String message) {
        super(message);
    }
}

public class Factorial {
    public static long factorial(int n) throws InvalidFactorialValueException {
        if (n < 0) throw new InvalidFactorialValueException("Negative number not allowed.");
        long result = 1;
        for (int i = 2; i <= n; i++) result *= i;
        return result;
    }

    public static void main(String[] args) {
        try {
            System.out.println(factorial(5));
            System.out.println(factorial(-2));
        } catch (InvalidFactorialValueException e) {
            System.out.println("Exception: " + e.getMessage());
        }
    }
}