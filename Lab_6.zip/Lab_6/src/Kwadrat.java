public class Kwadrat extends Prostokat {

    public Kwadrat(float side, String color) {
        super(side, side, color);
    }

    public float getSide() {
        return height;
    }

    public void setSide(float side) {
        this.height = side;
        this.width = side;
    }

    @Override
    public void describe() {
        System.out.println("Square with side = " + height + ", color: " + color);
    }
}