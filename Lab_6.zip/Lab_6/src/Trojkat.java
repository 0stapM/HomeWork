public class Trojkat extends Figura {
    private float base;
    private float height;

    public Trojkat(float base, float height, String color) {
        this.base = base;
        this.height = height;
        this.color = color;
    }

    @Override
    public void describe() {
        System.out.println("Triangle [base=" + base + ", height=" + height + ", color=" + color + "]");
    }
}