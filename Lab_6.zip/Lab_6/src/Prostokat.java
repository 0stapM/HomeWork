public class Prostokat extends Figura {
    protected float height;
    protected float width;
    protected Punkt position = new Punkt();

    public Prostokat() {
        this.height = 1;
        this.width = 1;
    }

    public Prostokat(float height, float width, String color) {
        this.height = height;
        this.width = width;
        this.color = color;
    }

    public void move(float dx, float dy) {
        position.move((int) dx, (int) dy);
    }

    @Override
    public void describe() {
        System.out.println("Rectangle [width=" + width + ", height=" + height + ", color=" + color + "]");
    }
}