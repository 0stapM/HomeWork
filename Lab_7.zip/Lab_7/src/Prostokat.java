public class Prostokat extends Figura implements IFigury {
    private float width, height;
    private Punkt position;

    public Prostokat(float width, float height, Punkt position) {
        this.width = width;
        this.height = height;
        this.position = position;
    }

    @Override
    public String opis() {
        return "Object of class Prostokat";
    }

    @Override
    public void skaluj(float skala) {
        width *= skala;
        height *= skala;
    }

    @Override
    public float getPowierzchnia() {
        return width * height;
    }

    @Override
    public boolean wPolu(Punkt p) {
        return p.x >= position.x && p.x <= position.x + width &&
                p.y >= position.y && p.y <= position.y + height;
    }
}