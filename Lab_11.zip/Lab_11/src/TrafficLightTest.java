
public class TrafficLightTest {
    public static void main(String[] args) {
        TrafficLight current = TrafficLight.YELLOW;

        System.out.println("Light: " + current);
        System.out.println("Message: " + current.getMessage());


        for (TrafficLight light : TrafficLight.values()) {
            System.out.println(light + ": " + light.getMessage());
        }
    }
}