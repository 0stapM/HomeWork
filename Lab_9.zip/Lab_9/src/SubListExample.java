import java.util.*;

public class SubListExample {
    public static void main(String[] args) {
        class Item {
            String name;
            Item(String name) { this.name = name; }
            public String toString() { return name; }
        }

        List<Item> allItems = new ArrayList<>(List.of(
                new Item("A"), new Item("B"), new Item("C"),
                new Item("D"), new Item("E")
        ));

        List<Item> sub = allItems.subList(1, 4); // B, C, D
        sub.clear();
        System.out.println("Remaining: " + allItems);
    }
}