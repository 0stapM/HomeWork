import java.util.Scanner;

public class StudentInputApp {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter first name: ");
        String firstName = scanner.nextLine();
        System.out.print("Enter last name: ");
        String lastName = scanner.nextLine();
        System.out.print("Enter index number: ");
        int index = scanner.nextInt();
        scanner.nextLine(); // clear buffer
        System.out.print("Enter specialization: ");
        String specialization = scanner.nextLine();
        System.out.print("Enter year of study: ");
        int year = scanner.nextInt();

        Student student = new Student(firstName, lastName, index, specialization, year);
        student.displayStudent();
    }
}