import java.util.*;

public class UserLogin {
    public static void main(String[] args) {
        Map<String, String> users = new HashMap<>();
        Scanner scanner = new Scanner(System.in);

        users.put("admin", "1234");

        System.out.print("Login: ");
        String login = scanner.nextLine();
        System.out.print("Password: ");
        String pass = scanner.nextLine();

        if (users.containsKey(login) && users.get(login).equals(pass)) {
            System.out.println("Logged in!");
        } else {
            System.out.println("Invalid credentials.");
        }
    }
}