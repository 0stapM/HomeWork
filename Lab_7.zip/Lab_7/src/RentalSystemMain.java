public class RentalSystemMain {
    public static void main(String[] args) {
        Vehicle car = new Car("Toyota");
        Vehicle bike = new Bike("Mountain Bike");
        Vehicle scooter = new Scooter("Electric Scooter");

        car.rent();
        System.out.println("Cost: $" + car.calculateRentalCost(3));
        car.returnVehicle();

        bike.rent();
        System.out.println("Cost: $" + bike.calculateRentalCost(2));
        bike.returnVehicle();

        scooter.rent();
        System.out.println("Cost: $" + scooter.calculateRentalCost(4));
        scooter.returnVehicle();
    }
}