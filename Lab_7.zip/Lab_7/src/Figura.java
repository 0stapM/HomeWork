public abstract class Figura {
    public abstract String opis();
    public abstract void skaluj(float skala);
}