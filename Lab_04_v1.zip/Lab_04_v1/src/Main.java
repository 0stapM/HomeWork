public static void main(String[] args) {
    System.out.println("Task 1:");
    Lab04Tasks.task1();
    System.out.println("\nTask 2:");
    Lab04Tasks.task2();
    System.out.println("\nTask 3:");
    Lab04Tasks.task3();
    System.out.println("\nTask 4:");
    Lab04Tasks.task4();
    System.out.println("\nTask 5:");
    Lab04Tasks.task5();
    System.out.println("\nTask 6:");
    Lab04Tasks.task6();
    System.out.println("\nTask 7:");
    Lab04Tasks.task7();
}