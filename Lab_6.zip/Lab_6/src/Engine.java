public class Engine {
    private int power; // in HP
    private String fuelType;

    public Engine(int power, String fuelType) {
        this.power = power;
        this.fuelType = fuelType;
    }

    public void startEngine() {
        System.out.println("Engine started: " + power + "HP, Fuel: " + fuelType);
    }
}