import java.util.*;

public class Lab04Tasks {

    // Task 1: Sum and average of array elements (using for and for-each)
    public static int[] generateRandomArray(int size, int min, int max) {
        Random rand = new Random();
        int[] array = new int[size];
        for (int i = 0; i < size; i++) {
            array[i] = rand.nextInt(max - min + 1) + min;
        }
        return array;
    }

    public static void task1() {
        int[] numbers = generateRandomArray(10, 0, 100);
        int sum = 0;
        System.out.println("Generated array:");
        for (int i = 0; i < numbers.length; i++) {
            sum += numbers[i];
            System.out.print(numbers[i] + " ");
        }
        System.out.println("\nSum (using for): " + sum);
        double average = (double) sum / numbers.length;
        System.out.println("Average: " + average);

        // Using for-each
        sum = 0;
        for (int num : numbers) {
            sum += num;
        }
        System.out.println("Sum (using for-each): " + sum);
    }

    // Task 2: Print every second element from two arrays
    public static void task2() {
        int[] evenArray = {10, 20, 30, 40, 50, 60};
        int[] oddArray = {1, 3, 5, 7, 9};

        System.out.println("Every second element in even-sized array:");
        for (int i = 0; i < evenArray.length; i += 2) {
            System.out.print(evenArray[i] + " ");
        }

        System.out.println("\nEvery second element in odd-sized array:");
        for (int i = 0; i < oddArray.length; i += 2) {
            System.out.print(oddArray[i] + " ");
        }
    }

    // Task 3: Convert string array to uppercase
    public static void task3() {
        String[] words = {"hello", "world", "java", "arrays"};
        System.out.println("Uppercase words:");
        for (String word : words) {
            System.out.println(word.toUpperCase());
        }
    }

    // Task 4: Reverse words and their order
    public static void task4() {
        Scanner scanner = new Scanner(System.in);
        String[] words = new String[5];

        for (int i = 0; i < 5; i++) {
            System.out.print("Enter word " + (i + 1) + ": ");
            words[i] = scanner.nextLine();
        }

        System.out.println("Reversed words in reverse order:");
        for (int i = words.length - 1; i >= 0; i--) {
            StringBuilder reversed = new StringBuilder(words[i]);
            System.out.println(reversed.reverse().toString());
        }
    }

    // Task 5: Sort and print 8 numbers
    public static void task5() {
        Scanner scanner = new Scanner(System.in);
        int[] numbers = new int[8];

        for (int i = 0; i < 8; i++) {
            System.out.print("Enter number " + (i + 1) + ": ");
            numbers[i] = scanner.nextInt();
        }

        Arrays.sort(numbers);
        System.out.println("Sorted numbers:");
        for (int num : numbers) {
            System.out.print(num + " ");
        }
    }

    // Task 6: Factorial of 5 user numbers
    public static long factorial(int n) {
        long result = 1;
        for (int i = 2; i <= n; i++) result *= i;
        return result;
    }

    public static void task6() {
        Scanner scanner = new Scanner(System.in);
        int[] numbers = new int[5];

        for (int i = 0; i < 5; i++) {
            System.out.print("Enter number " + (i + 1) + ": ");
            numbers[i] = scanner.nextInt();
        }

        System.out.println("Factorials:");
        for (int n : numbers) {
            System.out.println(n + "! = " + factorial(n));
        }
    }

    // Task 7: Compare two string arrays
    public static void task7() {
        String[] array1 = {"Java", "is", "fun"};
        String[] array2 = {"Java", "is", "fun"};

        boolean areEqual = Arrays.equals(array1, array2);
        if (areEqual) {
            System.out.println("The arrays are equal.");
        } else {
            System.out.println("The arrays are NOT equal.");
        }
    }


}