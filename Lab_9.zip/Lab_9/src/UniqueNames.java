import java.util.*;

public class UniqueNames {
    public static void main(String[] args) {
        Set<String> names = new HashSet<>();
        Scanner scanner = new Scanner(System.in);
        String input;
        while (true) {
            System.out.print("Enter name ('-' to stop): ");
            input = scanner.nextLine();
            if (input.equals("-")) break;
            names.add(input);
        }
        System.out.println("Unique names count: " + names.size());
    }
}