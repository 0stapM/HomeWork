public class Kwadrat extends Figura implements IFigury {
    private float side;

    public Kwadrat(float side) {
        this.side = side;
    }

    @Override
    public String opis() {
        return "Object of class Kwadrat";
    }

    @Override
    public void skaluj(float skala) {
        side *= skala;
    }

    @Override
    public float getPowierzchnia() {
        return side * side;
    }

    @Override
    public boolean wPolu(Punkt p) {
        return p.x >= 0 && p.x <= side && p.y >= 0 && p.y <= side;
    }
}