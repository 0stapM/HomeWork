public class Bike extends Vehicle {
    public Bike(String name) {
        super(name);
    }

    @Override
    public double calculateRentalCost(int hours) {
        return hours * 5.0;
    }
}