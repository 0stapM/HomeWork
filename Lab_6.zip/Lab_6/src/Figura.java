public class Figura {
    protected String color = "undefined";

    public void describe() {
        System.out.println("Generic figure, color: " + color);
    }
}