public class Trojkat extends Figura implements IFigury {
    private float base, height;

    public Trojkat(float base, float height) {
        this.base = base;
        this.height = height;
    }

    @Override
    public String opis() {
        return "Object of class Trojkat";
    }

    @Override
    public void skaluj(float skala) {
        base *= skala;
        height *= skala;
    }

    @Override
    public float getPowierzchnia() {
        return 0.5f * base * height;
    }

    @Override
    public boolean wPolu(Punkt p) {
        return false; // simplified
    }
}