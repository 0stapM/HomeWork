public class StudentManager {
    Student[] students = new Student[100];

    public StudentManager() {
        for (int i = 0; i < students.length; i++) {
            students[i] = new Student("", "", 0, "", 0);
        }
    }

    public void setStudentAt(int index, Student student) {
        if (index >= 0 && index < students.length) {
            students[index] = student;
        }
    }

    public void editStudentAt(int index, Student student) {
        setStudentAt(index, student);
    }

    public void deleteStudentAt(int index) {
        setStudentAt(index, new Student("", "", 0, "", 0));
    }

    public void displayStudentAt(int index) {
        if (index >= 0 && index < students.length) {
            students[index].displayStudent();
        }
    }

    public void displayAllStudents() {
        for (int i = 0; i < students.length; i++) {
            System.out.print("Index " + i + ": ");
            students[i].displayStudent();
        }
    }

    public void displayRange(int from, int to) {
        for (int i = from; i <= to && i < students.length; i++) {
            System.out.print("Index " + i + ": ");
            students[i].displayStudent();
        }
    }

    public static void main(String[] args) {
        StudentManager manager = new StudentManager();

        // Example usage
        manager.setStudentAt(0, new Student("Anna", "Smith", 12345, "Computer Science", 2));
        manager.setStudentAt(1, new Student("John", "Doe", 23456, "Mathematics", 1));
        manager.displayAllStudents();
        manager.deleteStudentAt(1);
        manager.displayStudentAt(1);
        manager.displayRange(0, 2);
    }
}