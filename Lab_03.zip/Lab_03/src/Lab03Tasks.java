import java.util.Scanner;
import java.util.Random;

public class Lab03Tasks {

    // Task 1: Average score of students using while loop
    public static void task1() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the number of students: ");
        int n = scanner.nextInt();

        int i = 0;
        double sum = 0;
        while (i < n) {
            System.out.print("Enter score for student " + (i + 1) + ": ");
            double score = scanner.nextDouble();
            sum += score;
            i++;
        }

        double average = sum / n;
        System.out.println("Average score: " + average);
    }

    // Task 2: Count and sum of negative and positive numbers
    public static void task2() {
        Scanner scanner = new Scanner(System.in);

        int positiveCount = 0, negativeCount = 0;
        int positiveSum = 0, negativeSum = 0;

        for (int i = 0; i < 10; i++) {
            System.out.print("Enter number " + (i + 1) + ": ");
            int num = scanner.nextInt();
            if (num > 0) {
                positiveCount++;
                positiveSum += num;
            } else if (num < 0) {
                negativeCount++;
                negativeSum += num;
            }
        }

        System.out.println("Positive count: " + positiveCount + ", sum: " + positiveSum);
        System.out.println("Negative count: " + negativeCount + ", sum: " + negativeSum);
    }

    // Task 3: Sum of even numbers in a sequence
    public static void task3() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter how many numbers to input: ");
        int n = scanner.nextInt();

        int evenSum = 0;
        for (int i = 0; i < n; i++) {
            System.out.print("Enter number " + (i + 1) + ": ");
            int num = scanner.nextInt();
            if (num % 2 == 0) {
                evenSum += num;
            }
        }

        System.out.println("Sum of even numbers: " + evenSum);
    }

    // Task 4: Random numbers in range (-10, 45) and sum of even ones
    public static void task4() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter how many numbers to generate: ");
        int n = scanner.nextInt();

        Random rand = new Random();
        int evenSum = 0;

        System.out.println("Generated numbers:");
        for (int i = 0; i < n; i++) {
            int num = rand.nextInt(56) - 10; // (-10 to 45)
            System.out.print(num + " ");
            if (num % 2 == 0) {
                evenSum += num;
            }
        }

        System.out.println("\nSum of even numbers: " + evenSum);
    }

    // Task 5: Check if word is a palindrome
    public static void task5() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter a word: ");
        String word = scanner.nextLine();

        String reversed = new StringBuilder(word).reverse().toString();

        if (word.equals(reversed)) {
            System.out.println("The word is a palindrome.");
        } else {
            System.out.println("The word is not a palindrome.");
        }
    }



}