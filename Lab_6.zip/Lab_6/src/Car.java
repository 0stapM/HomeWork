public class Car extends Vehicle {
    private int passengerCapacity;

    public Car(String brand, String model, int year, int maxSpeed, int passengerCapacity, Engine engine, FuelTank tank) {
        super(brand, model, year, maxSpeed, engine, tank);
        this.passengerCapacity = passengerCapacity;
    }

    @Override
    public void displayInfo() {
        super.displayInfo();
        System.out.println("Passenger Capacity: " + passengerCapacity);
    }
}