public abstract class Vehicle {
    protected String name;
    protected boolean rented;

    public Vehicle(String name) {
        this.name = name;
        this.rented = false;
    }

    public abstract double calculateRentalCost(int hours);

    public void rent() {
        if (!rented) {
            rented = true;
            System.out.println(name + " rented.");
        } else {
            System.out.println(name + " is already rented.");
        }
    }

    public void returnVehicle() {
        if (rented) {
            rented = false;
            System.out.println(name + " returned.");
        } else {
            System.out.println(name + " was not rented.");
        }
    }

    public boolean isRented() {
        return rented;
    }
}