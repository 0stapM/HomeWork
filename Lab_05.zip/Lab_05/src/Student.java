public class Student {
    String firstName;
    String lastName;
    int indexNumber;
    String specialization;
    int year;


    public Student(String firstName) {
        this.firstName = firstName;
        this.lastName = "";
        this.indexNumber = 0;
        this.specialization = "";
        this.year = 0;
    }

    public Student(String firstName, String lastName) {
        this(firstName);
        this.lastName = lastName;
    }

    public Student(String firstName, String lastName, int indexNumber) {
        this(firstName, lastName);
        this.indexNumber = indexNumber;
    }

    public Student(String firstName, String lastName, int indexNumber, String specialization, int year) {
        this(firstName, lastName, indexNumber);
        this.specialization = specialization;
        this.year = year;
    }

    public void displayStudent() {
        System.out.println("Student: " + firstName + " " + lastName + ", Index: " + indexNumber +
                ", Specialization: " + specialization + ", Year: " + year);
    }
}