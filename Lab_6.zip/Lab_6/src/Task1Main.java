public class Task1Main {
    public static void main(String[] args) {
        Engine carEngine = new Engine(120, "Petrol");
        FuelTank carTank = new FuelTank(50);
        Car car = new Car("Toyota", "Corolla", 2020, 180, 5, carEngine, carTank);

        Engine truckEngine = new Engine(400, "Diesel");
        FuelTank truckTank = new FuelTank(300);
        Truck truck = new Truck("Volvo", "FH16", 2018, 140, 25, truckEngine, truckTank);

        car.displayInfo();
        car.engine.startEngine();
        car.fuelTank.refuel(40);
        car.fuelTank.consume(20);

        System.out.println();

        truck.displayInfo();
        truck.engine.startEngine();
        truck.fuelTank.refuel(250);
        truck.fuelTank.consume(100);
    }
}