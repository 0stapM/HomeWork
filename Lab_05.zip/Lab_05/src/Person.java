public class Person {
    String firstName;
    String lastName;
    int age;


    public Person() {
        this.firstName = "";
        this.lastName = "";
        this.age = 0;
    }

    public Person(String firstName, int age) {
        this.firstName = firstName;
        this.lastName = "";
        this.age = age;
    }

    public Person(String firstName, String lastName, int age) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.age = age;
    }

    public void showData() {
        System.out.println("Name: " + firstName + " " + lastName + ", Age: " + age);
    }
}
