public class Okrag extends Figura {
    private Punkt center;
    private double radius;

    public Okrag() {
        this.center = new Punkt(0, 0);
        this.radius = 0;
    }

    public Okrag(Punkt center, double radius) {
        this.center = center;
        this.radius = radius;
    }

    public double getArea() {
        return Math.PI * radius * radius;
    }

    public double getDiameter() {
        return 2 * radius;
    }

    public void setRadius(double r) {
        this.radius = r;
    }

    public double getRadius() {
        return radius;
    }

    public boolean contains(Punkt p) {
        double dx = p.x - center.x;
        double dy = p.y - center.y;
        return dx * dx + dy * dy <= radius * radius;
    }

    @Override
    public void describe() {
        System.out.println("Circle with center (" + center.x + "," + center.y + "), radius: " + radius);
    }
}