public enum PizzaSize {
    SMALL(25, 19.99),
    MEDIUM(30, 25.99),
    LARGE(40, 32.99);

    private final int diameter;
    private final double price;

    PizzaSize(int diameter, double price) {
        this.diameter = diameter;
        this.price = price;
    }

    public int getDiameter() {
        return diameter;
    }

    public double getPrice() {
        return price;
    }
}