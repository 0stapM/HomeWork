class InvalidAddressException extends Exception {
    public InvalidAddressException(String message) {
        super(message);
    }
}

class Address {
    String street, postalCode, city;
    int houseNumber;

    public Address(String street, int houseNumber, String postalCode, String city) throws InvalidAddressException {
        StringBuilder sb = new StringBuilder();
        if (street == null) sb.append("Street cannot be null. ");
        if (houseNumber <= 0) sb.append("House number must be > 0. ");
        if (postalCode == null) sb.append("Postal code cannot be null. ");
        if (city == null) sb.append("City cannot be null.");
        if (sb.length() > 0) throw new InvalidAddressException(sb.toString());

        this.street = street;
        this.houseNumber = houseNumber;
        this.postalCode = postalCode;
        this.city = city;
    }

    @Override
    public String toString() {
        return street + " " + houseNumber + ", " + postalCode + " " + city;
    }
}

public class AddressTest {
    public static void main(String[] args) {
        try {
            Address a = new Address(null, -1, null, null);
        } catch (InvalidAddressException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}