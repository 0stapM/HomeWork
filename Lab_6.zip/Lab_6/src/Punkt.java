public class Punkt {
    public int x, y;

    public Punkt() {
        this.x = 0;
        this.y = 0;
    }

    public Punkt(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public void setX(int x) { this.x = x; }
    public void setY(int y) { this.y = y; }
    public int getX() { return x; }
    public int getY() { return y; }

    public void reset() {
        this.x = 0;
        this.y = 0;
    }

    public void describe() {
        System.out.println("Point coordinates: (" + x + ", " + y + ")");
    }

    public void move(int dx, int dy) {
        x += dx;
        y += dy;
    }
}