public interface RuchFigury {
    void przesun(int x, int y);
}