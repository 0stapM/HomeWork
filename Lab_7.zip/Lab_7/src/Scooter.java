public class Scooter extends Vehicle {
    public Scooter(String name) {
        super(name);
    }

    @Override
    public double calculateRentalCost(int hours) {
        return hours * 7.5;
    }
}