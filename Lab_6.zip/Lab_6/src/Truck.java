public class Truck extends Vehicle {
    private double loadCapacity;

    public Truck(String brand, String model, int year, int maxSpeed, double loadCapacity, Engine engine, FuelTank tank) {
        super(brand, model, year, maxSpeed, engine, tank);
        this.loadCapacity = loadCapacity;
    }

    @Override
    public void displayInfo() {
        super.displayInfo();
        System.out.println("Load Capacity: " + loadCapacity + " tons");
    }
}