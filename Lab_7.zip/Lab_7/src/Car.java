public class Car extends Vehicle {
    public Car(String name) {
        super(name);
    }

    @Override
    public double calculateRentalCost(int hours) {
        return hours * 15.0;
    }
}