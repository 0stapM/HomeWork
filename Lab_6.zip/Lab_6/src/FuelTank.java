public class FuelTank {
    private double capacity;
    private double currentLevel;

    public FuelTank(double capacity) {
        this.capacity = capacity;
        this.currentLevel = 0;
    }

    public void refuel(double amount) {
        currentLevel = Math.min(capacity, currentLevel + amount);
        System.out.println("Refueled. Current level: " + currentLevel);
    }

    public void consume(double amount) {
        if (amount > currentLevel) {
            System.out.println("Not enough fuel!");
        } else {
            currentLevel -= amount;
            System.out.println("Fuel consumed. Remaining: " + currentLevel);
        }
    }
}